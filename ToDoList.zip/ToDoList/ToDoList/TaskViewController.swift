//
//  TaskViewController.swift
//  ToDoList
//
//  Created by Даурен Урзаканов on 22.01.2025.
//

import UIKit

class TaskViewController: UIViewController {
    
    @IBOutlet var label: UILabel!
    
    var task: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        label.text = task
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Delete", style: .done, target: self, action: #selector(deleteTask))
    }
    
    @objc func deleteTask() {
        guard let task = task else { return }
        
        var tasks = [String]()
        guard let count = UserDefaults().value(forKey: "count") as? Int else { return }

        for x in 0..<count {
            if let savedTask = UserDefaults().value(forKey: "task_\(x + 1)") as? String {
                tasks.append(savedTask)
            }
        }

        if let index = tasks.firstIndex(of: task) {
            tasks.remove(at: index)
            UserDefaults().set(tasks.count, forKey: "count")
            for (i, task) in tasks.enumerated() {
                UserDefaults().set(task, forKey: "task_\(i + 1)")
            }
            navigationController?.popViewController(animated: true)
        }
    }

    
}

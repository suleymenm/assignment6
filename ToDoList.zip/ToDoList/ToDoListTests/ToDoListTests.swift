//
//  ToDoListTests.swift
//  ToDoListTests
//
//  Created by Даурен Урзаканов on 21.01.2025.
//

import Testing
@testable import ToDoList

struct ToDoListTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
